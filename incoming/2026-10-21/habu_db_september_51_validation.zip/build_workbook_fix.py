from artifact_tool import Workbook, SpreadsheetFile
from pathlib import Path
import csv,collections,datetime
OUT=Path('/mnt/data/ハブDB_2025-2026_10-20統合成果_9月51匹訂正')
W=Workbook.create()
NAVY='#17324A'; GREEN='#087D7A'; WHITE='#FFFFFF'; PALE='#EAF4F2'; PALEGREY='#F0F4F8'

def get_rows(name):
 with (OUT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def convert(x,field):
 if x is None:return ''
 if field in ('lat','lon','緯度','経度','latitude','longitude','distance_m','nearest_distance_m'):
  try:return float(x) if x!='' else ''
  except (ValueError,TypeError):return x
 if field in ('events','owner_captures','habu_sightings','habu_roadkills','others_capture_habu','other_animals','weather_notes','starts','ends','capture_gpx_pass','capture_gpx_not_verified','count_min','count','count_max'):
  try:return int(x) if str(x).strip() else ''
  except (ValueError,TypeError):return x
 return str(x) if not isinstance(x,(float,int,bool)) else x

def grid(sheet_name,fields,key_list,data,widths=None,table_name=None):
 sheet=W.worksheets.add(sheet_name)
 sheet.get_range_by_indexes(0,0,1,len(fields)).values=[fields]
 matrix=[[convert(row.get(k,''),k) for k in key_list] for row in data]
 chunk=400
 for a in range(0,len(matrix),chunk):
  sheet.get_range_by_indexes(a+1,0,min(chunk,len(matrix)-a),len(fields)).values=matrix[a:a+chunk]
 sheet.get_range_by_indexes(0,0,1,len(fields)).format={'fill':NAVY,'font':{'bold':True,'color':WHITE},'row_height':25,'vertical_alignment':'center'}
 sheet.freeze_panes.freeze_rows(1)
 for i,width in enumerate(widths or [18]*len(fields)):
  sheet.get_range_by_indexes(0,i,1,1).format.column_width=width
 if table_name and len(data)<1400:
  sheet.tables.add(sheet.get_range_by_indexes(0,0,len(data)+1,len(fields)),True,table_name)
 print('created',sheet_name,len(matrix),len(fields),flush=True)
 return sheet

summary=get_rows('探索夜別_2026-09_10.csv')
sept=[r for r in summary if r['night'].startswith('2026-09')]
oct=[r for r in summary if r['night'].startswith('2026-10')]
allhist=get_rows('全期間イベント統合_2025-2026.csv')
new=get_rows('新規イベント_2026-09_10.csv')
captures=get_rows('新規ハブ捕獲_2026-09_10.csv')
react=get_rows('新規生物反応_2026-09_10.csv')
gpx=get_rows('GPS照合_新規本人捕獲.csv')
exc=get_rows('要確認_例外候補.csv')
duplicates=get_rows('重複監査_同一イベント.csv')

s=W.worksheets.add('統合サマリー')
s.merge_cells('A1:H2');s.get_range('A1').values=[['HABU AI  |  捕獲・生物反応統合データベース']]
s.get_range('A1:H2').format={'fill':NAVY,'font':{'bold':True,'color':WHITE,'size':17},'row_height':30,'vertical_alignment':'center'}
s.get_range('A4:B9').values=[['統合最終探索夜','2026-10-20'],['統合期間','2025-09〜2026-10'],['2026年9月捕獲個体数',51],['2026年10月捕獲個体数',17],['GPX照合済み捕獲イベント',67],['新規の一意イベント',1117]]
s.get_range('D4:E8').values=[['新規ログの照合','結果'],['2026年9月','原本ログ893件'],['2026年10月','転記ログ224件'],['2025年捕獲曖昧行','分類を維持'],['正式予測P0','変更なし']]
s.get_range('A4:A9').format={'fill':PALE,'font':{'bold':True,'color':NAVY}}
s.get_range('D4:E4').format={'fill':PALE,'font':{'bold':True,'color':NAVY}}
s.get_range('A11:E11').values=[['月別追加集計','本人捕獲','非捕獲のハブ反応','その他生物イベント','探索ログイベント総数']]
s.get_range('A12:E13').values=[['2026-09',51,sum(int(r['habu_sightings'])+int(r['habu_roadkills'])+int(r['others_capture_habu']) for r in sept),sum(int(r['other_animals']) for r in sept),sum(int(r['events']) for r in sept)],['2026-10',17,sum(int(r['habu_sightings'])+int(r['habu_roadkills'])+int(r['others_capture_habu']) for r in oct),sum(int(r['other_animals']) for r in oct),sum(int(r['events']) for r in oct)]]
s.get_range('A11:E11').format={'fill':GREEN,'font':{'color':WHITE,'bold':True},'row_height':24}
s.get_range('A15:H15').values=[['ご注意：元DB（2026年8月29日版）は別ファイルとして原本保管し、今回のExcelには全期間統合ビューを収録しています。']+['']*7]
s.merge_cells('A15:H15');s.get_range('A15').format={'font':{'color':'#8C4A13','bold':True},'row_height':27}
s.get_range('A16:H16').values=[['ハブ目撃・他者捕獲・轢死・ヒメハブは本人のハブ捕獲に足していません。']+['']*7];s.merge_cells('A16:H16')
s.get_range('A17:H17').values=[['同じログの再投稿は再加算しません。複数生物の併記と2025年の捕獲/目撃未確定記録は分離・要確認のまま。']+['']*7];s.merge_cells('A17:H17')
for col,width in zip('ABCDEFGH',[26,22,23,23,26,17,17,17]):s.get_range(f'{col}:{col}').format.column_width=width
try:
 ch=s.charts.add('ColumnClustered',s.get_range('A11:B13'));ch.title_text='新規本人捕獲（9月 / 10月）';ch.set_position('G4','N13')
except Exception as e:print('Chart skipped',type(e).__name__,flush=True)
print('summary done',flush=True)

nightkeys=['night','events','owner_captures','habu_sightings','habu_roadkills','others_capture_habu','other_animals','weather_notes','starts','ends','capture_gpx_pass','capture_gpx_not_verified']
grid('探索夜別_9月10月',['探索夜','イベント','本人捕獲','ハブ目撃','ハブ轢死','他者捕獲','その他生物','天候メモ','探索開始','探索終了','GPX照合済','未照合'],nightkeys,summary,[17,14,14,14,14,14,14,14,14,14,17,14],'NightHabuSepOct')

grid('新規ハブ捕獲_67イベント',['記録ID','探索夜','捕獲時刻','サイズ原文','性別','行動','発見位置','路面','緯度','経度','場所','ソース'],['record_id','exploration_night','event_time_jst','size_raw','sex','behavior','position','surface_raw','latitude','longitude','location_text','source_file'],captures,[27,18,23,25,10,17,17,13,20,20,28,27],'CaptureHabuNew')

indv=get_rows('新規ハブ捕獲個体_2026-09_10.csv')
grid('本人捕獲個体_68匹',['個体ID','捕獲イベントID','イベント内順番','捕獲時刻','探索夜','ハブ','緯度','経度','サイズ','性別','原本行'],['individual_id','event_id','individual_index','event_time_jst','exploration_night','species','latitude','longitude','size_raw','sex','source_locator'],indv,[33,27,16,24,19,14,20,20,26,13,18],'IndividualsNewSepOct')

grid('新規全イベント_9月10月',['記録ID','時刻','探索夜','分類','種類','数量原文','数量下限','緯度','経度','路面','サイズ','性別','姿勢','位置','場所','要確認理由','ソースファイル','原文根拠位置'],['record_id','event_time_jst','exploration_night','event_class','species_normalized','count_raw','count_min','latitude','longitude','surface_raw','size_raw','sex','behavior','position','location_text','review_reason','source_file','source_locator'],new,[27,23,17,29,27,16,14,19,19,13,23,11,19,18,30,33,29,18],'EventsAddedSepOct')

grid('新規生物反応_9月10月',['記録ID','観測時刻','探索夜','種別','生物名（併記あり）','数量原文','数量下限','緯度','経度','路面','場所','品質','原文ファイル'],['record_id','event_time_jst','exploration_night','event_class','species_normalized','count_raw','count_min','latitude','longitude','surface_raw','location_text','data_quality','source_file'],react,[26,23,17,25,34,16,14,19,19,14,28,26,28],'ReactionEventsNew')

# 3,853 rows intentionally are stored as a flat, filter-ready table with source lineage.
grid('全期間統合イベント',['記録ID','観測時刻','探索夜','分類','生物名','数量','数量下限','緯度','経度','路面','サイズ','場所','品質','要確認','ソース','ソース位置','旧シート'],['record_id','event_time_jst','exploration_night','event_class','species_normalized','count_raw','count_min','latitude','longitude','surface_raw','size_raw','location_text','data_quality','review_reason','source_file','source_locator','orig_sheet'],allhist,[27,23,18,32,28,16,14,20,20,15,22,28,21,30,31,25,26])

grid('GPX照合_新規67イベント',['捕獲ID','探索夜','時刻','緯度','経度','GPXファイル','最近傍距離m','最近傍JST','時間差s','判定'],['record_id','exploration_night','capture_time_jst','lat','lon','gpx_filename','nearest_distance_m','nearest_point_time_jst','time_delta_seconds','gpx_match_status'],gpx,[27,18,23,20,20,36,18,24,16,25],'CaptureGPXMatch')

grid('要確認・例外',['出典','記録ID','観測時刻','要確認理由','取り扱い'],['source','event_id','timestamp','issue','action'],exc,[21,26,22,46,52],'HabuExceptions')

if duplicates:
 grid('重複監査',['除外記録ID','採用記録ID','時刻','根拠','重複キー','出典'],['removed_record_id','retained_record_id','timestamp','reason','duplicate_sha','source'],duplicates,[24,24,24,47,28,27])
else:
 d=W.worksheets.add('重複監査')
 d.get_range('A1:D3').values=[['照合対象','結果','備考','規則'],['9月原本＋10月会話の一意イベント','重複0件','繰り返し貼られた過去会話を追加インポートしていない','日時＋種別＋座標＋数量等'],['2025年既存DB','変更なし','旧DB内の要確認候補は削除しない','元データ保持']]
 d.get_range('A1:D1').format={'fill':NAVY,'font':{'color':WHITE,'bold':True}}
 for a,width in zip('ABCD',[31,19,58,33]):d.get_range(f'{a}:{a}').format.column_width=width

meta=W.worksheets.add('出典・注意事項')
metarows=[['項目','値'],['元DB','ハブDB_2025-2026_08-29完全統合版.xlsx'],['元DBのSHA-256','8980fd9c857d58bd9ddde92bec36573eb4aac422dd9d51ac04355af743d3d43b'],['2026年9月ログ','ハブログ9月.txt: 原本受領・893ブロック'],['2026年10月ログ','チャット内の繰り返し投稿を統合した224イベント、原文のbyte-exact exportではない'],['2026年10月元資料','GitHub PR#39: https://github.com/haji84/habuAI-private/pull/39'],['GPX','2026-09・10月の受領済み実GPXと±10分／100m照合'],['追加された捕獲','本人68匹（67捕獲イベント）。ハブ以外、轢死、目撃、他人捕獲は除外。'],['2025年の疑義記録','capture_or_sighting は確定捕獲に変更しない'],['路面・雨','ログ原文の記録のみ。過去の未観測気象数値を創作しない'],['不明＝非捕獲ではない','未探索の区間はUnknown。GPX通過記録のみ捕獲なし観測候補'],['夜の区切り','毎日07:00 JST。00:00〜06:59は前日探索夜へ計上。'],['10月18日18:48異常','同時刻の探索終了と開始が併記、開始を採用し終了は例外記録に保留。'],['月別表の扱い','元DB内の2026年8月までのダッシュボードは再評価していない'],['未来漏洩対策','後日結合した環境情報は過去のP0へ遡及しない'],['PR/main','本ブック作成はGitHub mainの変更を意味しない。']]
meta.get_range_by_indexes(0,0,len(metarows),2).values=metarows
meta.get_range('A1:B1').format={'fill':NAVY,'font':{'color':WHITE,'bold':True},'row_height':24}
meta.get_range('A:A').format.column_width=34
meta.get_range('B:B').format.column_width=80
meta.freeze_panes.freeze_rows(1)


# Complete historical source views, with existing records explicitly distinguished
# from additional September/October events (no deletion/overwrite of baseline).
cap_all=get_rows('本人捕獲_全期間原DB+追加.csv')
grid('捕獲原DBと追加_314件',['記録ID','日付','時刻','探索夜','元イベント分類','取込判定','生物種','数量','サイズ','地域','緯度','経度','路面','GPX判定','ソース'],['source_record','date','time','night','event_type_original','classification','species','count','size','area','lat','lon','surface','gpx_status','source'],cap_all,[28,18,16,18,26,42,14,12,18,31,19,19,14,30,39],'BaseCapturePlusAdded')

# Biological reaction history also retained, and append-only view built.
reac_all=[]
base_reac_rows=get_rows('base_bioreaction_original.csv') if (OUT/'base_bioreaction_original.csv').exists() else []
# The source snapshot itself lives outside OUT; never treat this view as a second source for model training.
with Path('/mnt/data/habu_merge_work/base_bioreaction_original.csv').open(encoding='utf-8-sig',newline='') as f:
 import csv as _csv
 base_reac_rows=list(_csv.DictReader(f))
for r in base_reac_rows:
 reac_all.append({'date':r['日付'],'time':r['時刻'],'class':'BASE_'+r['イベント'],'species':r['種別'],'count':r['数'],'place':r['地域'],'lat':r['緯度'],'lon':r['経度'],'surface':'','source':r['ソース'],'status':'BASE_ORIGINAL_NOT_RECERTIFIED'})
for r in react:
 reac_all.append({'date':r['event_time_jst'][:10],'time':r['event_time_jst'][11:],'class':r['event_class'],'species':r['species_normalized'],'count':r['count_raw'],'place':r['location_text'],'lat':r['latitude'],'lon':r['longitude'],'surface':r['surface_raw'],'source':r['source_file'],'status':'NEW_UNIQUE_EVENT'})
grid('生物反応DB_元表と追加',['日付','時刻','元/新規分類','生物種','数量','場所','緯度','経度','路面','原本・出典','品質'],['date','time','class','species','count','place','lat','lon','surface','source','status'],reac_all,[17,15,29,31,14,31,19,19,13,34,37])

print('exporting...',flush=True)
OUTPUT='/mnt/data/ハブDB_2025-2026_10-20統合更新版_9月51匹訂正版.xlsx'
SpreadsheetFile.export_xlsx(W).save(OUTPUT)
print('EXPORTED',OUTPUT,Path(OUTPUT).stat().st_size,flush=True)
try:
 print(W.inspect({'kind':'table','range':'統合サマリー!A4:E13','include':'values,formulas','table_max_rows':11,'table_max_cols':5}).ndjson[:2600],flush=True)
except Exception as e:print('inspect_error',str(e)[:250],flush=True)
