from __future__ import annotations
import csv, re, hashlib, json, collections
from pathlib import Path
from datetime import datetime,timedelta

ROOT=Path('/mnt/data')
STAMP=re.compile(r'(?m)^(2026/(?:09|10)/\d{2}\s+\d{1,2}:\d{2})(?:[^\n]*)\n')
POS=re.compile(r'^\s*28\.\d{3,}\s*$')
LON=re.compile(r'^\s*129\.\d{3,}\s*$')
PAIR=re.compile(r'(28\.\d{6,})(129\.\d{6,})')
COUNT=re.compile(r'^(\d+)匹(以上)?$')
SURF_MAP={'ドライ':'DRY','ウエット':'WET','ウェット':'WET','ソークド(水跳ね)':'SOAKED'}
SPECIES={'ハブ','ヒメハブ','アカマタ','リュウキュウアオヘビ','ヤマシギ','ネズミ','カエル','クロウサギ','オットンガエル','イシカワガエル','アマミハナサキガエル','リュウキュウコノハズク','リュウキュウアオバズク','アカショウビン','ヒャン','シラガケナガネズミ','ガラスヒヴァ','ガラスヒバァ','ウシガエル'}
IGN={'目撃','捕獲','轢死','エリア探索開始','エリア探索終了','日本','目撃 他の人が捕獲','1匹','2匹','3匹','4匹'}
COLS=['record_id','event_time_jst','exploration_night','event_class','species_raw','species_normalized','count_raw','count_min','count_max','count_is_lower_bound','latitude','longitude','surface_raw','surface_normalized','size_raw','sex','behavior','position','location_text','weather_notes','data_quality','review_reason','source_file','source_locator','source_text','dedup_key','dedup_status','provenance']

def opnight(dt:datetime)->str:
 return (dt-timedelta(days=1)).date().isoformat() if dt.hour<7 else dt.date().isoformat()

def build_event(dt,etype,species='',nraw='',lat='',lon='',surface='',size='',sex='',behavior='',position='',place='',weather='',source='',locator='',block='',quality='TRANSCRIBED',review='',provenance='USER_LOG'):
 count_match=COUNT.fullmatch(str(nraw).strip())
 if nraw and not count_match:review=(review+';COUNT_AMBIGUOUS').strip(';')
 count_min=int(count_match.group(1)) if count_match else (1 if etype=='CAPTURE_HABU' else '')
 count_max='' if not count_match or count_match.group(2) else (count_min if count_match else '')
 count_flag=bool(count_match and count_match.group(2))
 normalized=species.replace('＋','+').replace('・','+').strip()
 if normalized=='オットンカエル':normalized='オットンガエル'
 if len(normalized.split('+'))>1: review=(review+';MULTISPECIES_COUNT_UNALLOCATED').strip(';')
 if etype=='CAPTURE_HABU':normalized='ハブ'
 surface_n=SURF_MAP.get(surface,'UNKNOWN')
 tt=dt.strftime('%Y-%m-%d %H:%M')
 location_key=(round(float(lat),5),round(float(lon),5)) if lat and lon else (place.strip() or '')
 # Separate observations at different coordinates, species, status or time; don't collapse mixed-species or simultaneous captures.
 keyjson=json.dumps([tt,etype,normalized,nraw,location_key,surface_n,size],ensure_ascii=False,separators=(',',':'))
 k=hashlib.sha256(keyjson.encode()).hexdigest()[:24]
 record_id='HE'+hashlib.sha256((source+'|'+locator+'|'+keyjson).encode()).hexdigest()[:18]
 return dict(zip(COLS,[record_id,tt,opnight(dt),etype,species,normalized,nraw,count_min,count_max,count_flag,lat,lon,surface,surface_n,size,sex,behavior,position,place,weather,quality,review,source,locator,block,k,'NEW',provenance]))

def extract_coords(lines):
 for i,s in enumerate(lines):
  m=PAIR.search(s)
  if m:
   try:
    a,b=float(m.group(1)),float(m.group(2))
    if 27<a<30 and 128<b<131:return m.group(1),m.group(2)
   except ValueError:pass
  if POS.match(s) and i+1<len(lines) and LON.match(lines[i+1]):return s.strip(),lines[i+1].strip()
 return '',''

def extract_species(lines,etype):
 if etype=='CAPTURE_HABU':return 'ハブ'
 acc=[]
 for s in lines:
  if s in SPECIES:acc.append(s)
  if s.startswith('ハブ捕獲') and etype!='CAPTURE_HABU':acc.append('ハブ')
 return '+'.join(dict.fromkeys(acc))

def parse_september(file:Path):
 txt=file.read_text('utf-8-sig')
 found=list(STAMP.finditer(txt)); out=[]; exceptions=[]
 for i,m in enumerate(found):
  raw=txt[m.start():found[i+1].start() if i+1<len(found) else len(txt)].strip('\n\r')
  dt=datetime.strptime(m.group(1),'%Y/%m/%d %H:%M')
  if opnight(dt)<'2026-09-01' or opnight(dt)>'2026-09-30':continue
  body=raw[len(m.group(1)):]
  lines=[a.strip() for a in body.splitlines() if a.strip()]
  if 'エリア探索開始' in lines: typ='SESSION_START'
  elif 'エリア探索終了' in lines:typ='SESSION_END'
  elif '目撃 他の人が捕獲' in lines:typ='OTHER_PERSON_CAPTURE_HABU' if 'ハブ' in lines else 'OTHER_PERSON_CAPTURE_OTHER'
  elif '捕獲' in lines:typ='CAPTURE_HABU' if any('ハブ' in x for x in lines) else 'CAPTURE_OTHER_UNVERIFIED'
  elif '轢死' in lines:typ='ROADKILL_HABU' if 'ハブ' in lines else 'ROADKILL_OTHER'
  elif '目撃' in lines:typ='SIGHTING_HABU' if 'ハブ' in lines else 'SIGHTING_OTHER'
  else:typ='WEATHER_OR_MEMO'
  lat,lon=extract_coords(lines)
  surf=next((x for x in lines if x in SURF_MAP),'')
  # Count individuals, NOT just capture-event rows. A capture event may say
  # '畑 枯れ木 2匹' rather than having a separate 2匹 quantity line.
  # In combined capture+other-species blocks, a trailing '目撃 ... 1匹'
  # belongs to the sighting and MUST NOT set the Habu capture quantity.
  capture_lines=lines[:lines.index('目撃')] if typ=='CAPTURE_HABU' and '目撃' in lines else lines
  count=next((x for x in capture_lines if COUNT.fullmatch(x)),'')
  embedded_counts=[]
  if typ=='CAPTURE_HABU':
   for x in capture_lines:
    if x not in ('捕獲',) and not COUNT.fullmatch(x):
     hits=re.findall(r'(?<!\d)(\d+)匹(?!以上)',x)
     embedded_counts.extend((int(value),x) for value in hits)
   if not count and len(embedded_counts)==1:
    count=str(embedded_counts[0][0])+'匹'
  sp=extract_species(lines,typ)
  size=next((x for x in lines if x.startswith('ハブ捕獲')),'') if typ=='CAPTURE_HABU' else ''
  sex='メス' if 'メス' in size else ('オス' if 'オス' in size else '')
  beh=next((x for x in lines if x in ('とぐろ','移動中','伸び','待機中','頭上げ姿勢') or '移動中' in x),'')
  pos=next((x for x in lines if x in ('道路脇','道路中央','山裾','側溝','木の上','ブロック上','畑 枯れ木上') or x.startswith('山裾')),'')
  places=[s for s in lines if any(v in s for v in ('瀬戸内町','奄美市','龍郷町','宇検村','県道','国道'))]
  place=places[-1] if places else ''
  weather=' / '.join(s for s in lines if any(x in s for x in ('雨','晴','霧','雷','稲光','気温')))
  quality='LOG_EXACT_TEXT'
  reason=''
  if typ=='CAPTURE_HABU' and len(embedded_counts)>1:reason='AMBIGUOUS_EMBEDDED_INDIVIDUAL_COUNTS'
  if typ=='CAPTURE_HABU' and embedded_counts and count and len(embedded_counts)==1 and embedded_counts[0][0]!=int(COUNT.fullmatch(count).group(1)):
   reason=(reason+';EMBEDDED_COUNT_CONFLICT').strip(';')
  if typ.startswith(('CAPTURE','SIGHTING','ROADKILL')) and not sp:quality='NEEDS_REVIEW';reason='SPECIES_MISSING'
  if typ=='CAPTURE_HABU' and not (lat and lon):reason=(reason+';CAPTURE_GPS_MISSING').strip(';')
  if len(sp.split('+'))>1:reason=(reason+';MULTISPECIES_COUNT_UNALLOCATED').strip(';')
  e=build_event(dt,typ,sp,count,lat,lon,surf,size,sex,beh,pos,place,weather,file.name,f'line_{txt[:m.start()].count(chr(10))+1}',raw,quality,reason,'RAW_TEXT_2026_09')
  out.append(e)
  if reason:exceptions.append({'event_time':e['event_time_jst'],'event_id':e['record_id'],'issue':reason})
 return out,exceptions,len(found)

if __name__=='__main__':
 rows,errors,n=parse_september(ROOT/'ハブログ9月.txt');print('SEPTEMBER',len(rows),collections.Counter(r['event_class'] for r in rows),'errors',len(errors),'timestamp',n)
 print('captures',sum(1 for r in rows if r['event_class']=='CAPTURE_HABU'))
 for e in rows[:5]:print(e['event_time_jst'],e['event_class'],e['species_raw'],e['latitude'],e['longitude'])

def parse_october_compact(file:Path):
 out=[];issues=[]
 cclasses={'START':'SESSION_START','END':'SESSION_END','CAP':'CAPTURE_HABU','OBS':'SIGHTING_OTHER','ROAD':'ROADKILL_OTHER','WEATHER':'WEATHER_OR_MEMO'}
 for lineno,line in enumerate(file.read_text('utf-8').splitlines(),1):
  if not line.strip() or line.startswith('#'):continue
  pieces=line.split('|')
  if len(pieces)!=8:
   issues.append({'source':'october_transcript','line':lineno,'issue':'BAD_FIELD_COUNT','value':line});continue
  st,kind,species,quantity,lat,lon,surface,notes=pieces
  dt=datetime.strptime(st,'%Y-%m-%d %H:%M')
  typ=cclasses[kind]
  if kind=='OBS' and species=='ハブ':typ='SIGHTING_HABU'
  if kind=='ROAD' and species=='ハブ':typ='ROADKILL_HABU'
  attrs=[x.strip() for x in notes.split(';')]
  size=attrs[0] if kind=='CAP' and attrs else ''
  sex='メス' if 'メス' in size else ('オス' if 'オス' in size else '')
  beh=next((a for a in attrs if a in ('移動中','待機中','とぐろ','伸び','頭上げ姿勢')),'')
  pos=next((a for a in attrs if a in ('道路脇','道路中央','木の上','側溝','山裾','ブロック上')),'')
  place=next((a for a in attrs if ('瀬戸内町' in a or '奄美市' in a or '龍郷町' in a)),'')
  if not place and kind not in ('CAP',):place=notes.strip()
  event=build_event(dt,typ,species,quantity,lat,lon,surface,size,sex,beh,pos,place,notes if kind=='WEATHER' else '',file.name,f'line_{lineno}',line,
                  quality='CHAT_LOG_TRANSCRIBED',review='',provenance='USER_CHAT_2026_10_PR39_CROSSCHECK_6_15')
  if kind=='OBS' and '+' in species:
   event['review_reason']='MULTISPECIES_COUNT_UNALLOCATED'
  out.append(event)
 assert not issues,issues
 return out,issues


def dedupe_new(rows:list[dict]):
 seen={};kept=[];duplicate=[];collision=[]
 for row in rows:
  key=row['dedup_key']
  if key in seen:
   row['dedup_status']='EXACT_NORMALIZED_DUPLICATE'
   duplicate.append({'removed_record_id':row['record_id'],'retained_record_id':seen[key]['record_id'],'timestamp':row['event_time_jst'],'reason':'same minute,event,species,quantity,5decimal coordinate/surface/size key','duplicate_sha':key,'source':row['source_file']})
  else:
   seen[key]=row;kept.append(row)
 # Detect same timestamp + nearby positions but different kinds as possible conflicts, never auto remove.
 by_time=collections.defaultdict(list)
 for row in kept:by_time[row['event_time_jst']].append(row)
 for dt,g in by_time.items():
  for i,left in enumerate(g):
   for right in g[i+1:]:
    if left['event_class']==right['event_class'] and left['species_normalized']==right['species_normalized'] and left['latitude'] and right['latitude']:
     import math
     dist=((float(left['latitude'])-float(right['latitude']))*111000)**2+((float(left['longitude'])-float(right['longitude']))*98000)**2
     if dist<100:collision.append({'time':dt,'event_a':left['record_id'],'event_b':right['record_id'],'approx_dist_m':round(dist**.5,1),'reason':'same-minute near-point repeated species; preserved for review'})
 return kept,duplicate,collision

if __name__=='__main__':
 oct_rows,issues=parse_october_compact(ROOT/'habu_october_compact_source_20261021.txt')
 kept,dups,collisions=dedupe_new(rows+oct_rows)
 print('OCTOBER',len(oct_rows),collections.Counter(r['event_class'] for r in oct_rows))
 print('OCT CAP',collections.Counter(r['exploration_night'] for r in oct_rows if r['event_class']=='CAPTURE_HABU'))
 print('UNIQUE',len(kept),'dups',len(dups),'collision',len(collisions))
 print('OCT NIGHT EVENTS',collections.Counter(r['exploration_night'] for r in oct_rows))
