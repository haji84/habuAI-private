import unittest,csv
from pathlib import Path
ROOT=Path('/mnt/data/ハブDB_2025-2026_10-20統合成果_9月51匹訂正')
def read(n):
 with (ROOT/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
class CountTests(unittest.TestCase):
 def test_aggregate(self):
  ev=read('新規ハブ捕獲_2026-09_10.csv');i=read('新規ハブ捕獲個体_2026-09_10.csv')
  self.assertEqual(len(ev),67);self.assertEqual(len(i),68)
  self.assertEqual(sum(int(x['count_min']) for x in ev if x['exploration_night'].startswith('2026-09')),51)
 def test_simultaneous_two_individuals(self):
  ev=read('新規ハブ捕獲_2026-09_10.csv');i=read('新規ハブ捕獲個体_2026-09_10.csv')
  e=[x for x in ev if x['event_time_jst']=='2026-09-29 00:00']
  self.assertEqual(len(e),1);self.assertEqual(int(e[0]['count_min']),2);self.assertEqual(e[0]['exploration_night'],'2026-09-28')
  rows=[x for x in i if x['event_id']==e[0]['record_id']]
  self.assertEqual(len(rows),2);self.assertEqual(set(x['individual_index'] for x in rows),{'1','2'})
  self.assertEqual(len({(x['latitude'],x['longitude']) for x in rows}),1)
 def test_after_midnight(self):
  n=read('探索夜別_2026-09_10.csv');self.assertEqual([int(x['owner_captures']) for x in n if x['night']=='2026-09-28'],[6])
if __name__=='__main__':unittest.main()
