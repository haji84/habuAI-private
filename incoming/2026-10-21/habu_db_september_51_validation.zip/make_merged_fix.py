from __future__ import annotations
import sys,csv,json,hashlib,collections,re,datetime,math,zipfile
from pathlib import Path
sys.path.insert(0,'/mnt/data/habu_merge_fix_20261021')
from habu_merge_20261021_fix import (ROOT,COLS,parse_september,parse_october_compact,dedupe_new,opnight)
SRC=Path('/mnt/data/habu_merge_work')
OUT=Path('/mnt/data/ハブDB_2025-2026_10-20統合成果_9月51匹訂正')
OUT.mkdir(exist_ok=True)

def read_csv(path):
 with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write_csv(path,rows,fields):
 with open(path,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

seps,sep_errors,nraw=parse_september(ROOT/'ハブログ9月.txt')
octs,oct_errors=parse_october_compact(ROOT/'habu_october_compact_source_20261021.txt')
new,dups,collisions=dedupe_new(seps+octs)
assert len(seps)==893 and len(octs)==224
assert sum(r['event_class']=='CAPTURE_HABU' for r in seps)==50
assert sum(int(r['count_min']) for r in seps if r['event_class']=='CAPTURE_HABU')==51
assert sum(r['event_class']=='CAPTURE_HABU' for r in octs)==17
assert len(new)==1117
assert sum(int(r['count_min']) for r in new if r['event_class']=='CAPTURE_HABU')==68

# Original workbook snapshots are left unchanged. Only 2025/2026-Apr baselines
# enter full event materialization from capture DB; May-Aug uses normalized DB,
# avoiding double ingestion of the same old capture in two preexisting sheets.
orig_norm=read_csv(SRC/'base_normalized_original.csv')
orig_cap=read_csv(SRC/'base_capture_original.csv')
orig_bio=read_csv(SRC/'base_bioreaction_original.csv')
NEW_COLUMNS=COLS

BASE_VIEW_COLS=['record_id','event_time_jst','exploration_night','event_class','species_raw','species_normalized','count_raw','count_min','latitude','longitude','surface_raw','surface_normalized','size_raw','location_text','source_file','source_locator','data_quality','review_reason','original_sheet','original_id','legacy_event_type','raw_event_excerpt']

historical=[]
for row_number,r in enumerate(orig_norm,2):
 dt_str=str(r.get('日時') or '')
 if not dt_str:continue
 try:dt=datetime.datetime.fromisoformat(dt_str)
 except ValueError:continue
 old_type=(r.get('イベント正規化') or r.get('イベント原文') or '')
 species=r.get('種別正規化') or r.get('種別原文') or ''
 other_capture=r.get('他者捕獲')=='Y'
 if other_capture:etype='OTHER_PERSON_CAPTURE_HABU' if species=='ハブ' else 'OTHER_PERSON_CAPTURE_OTHER'
 elif old_type=='捕獲':etype='CAPTURE_HABU' if species=='ハブ' else 'CAPTURE_OTHER_UNVERIFIED'
 elif old_type=='目撃':etype='SIGHTING_HABU' if species=='ハブ' else 'SIGHTING_OTHER'
 elif old_type=='轢死':etype='ROADKILL_HABU' if species=='ハブ' else 'ROADKILL_OTHER'
 elif old_type=='探索開始':etype='SESSION_START'
 elif old_type=='探索終了':etype='SESSION_END'
 elif old_type=='気象':etype='WEATHER_OR_MEMO'
 else:etype='OTHER_MEMO'
 orig_id=r.get('ログID') or ''
 q=r.get('数量原文') or ''
 lo=r.get('数量下限') or ''
 lat=r.get('緯度') or '';lon=r.get('経度') or ''
 # Do not assert 2026 initial extraction represents confirmed individual count.
 historical.append(dict(record_id='BASE_NORM_'+str(row_number-1),event_time_jst=dt.strftime('%Y-%m-%d %H:%M'),exploration_night=opnight(dt),event_class=etype,species_raw=r.get('種別原文') or '',species_normalized=species,count_raw=q,count_min=lo,latitude=lat,longitude=lon,surface_raw=r.get('路面原文') or '',surface_normalized=r.get('路面正規化') or '',size_raw=r.get('サイズ原文') or '',location_text=r.get('地域原文') or '',source_file=r.get('ソース') or 'base_xlsx',source_locator='正規化イベントDB row '+str(row_number),data_quality=r.get('品質') or 'BASE_IMPORTED',review_reason=r.get('要確認理由') or '',original_sheet='正規化イベントDB',original_id=orig_id,legacy_event_type=r.get('イベント原文') or '',raw_event_excerpt=(r.get('元ブロック') or '')[:900]))
# Earlier historical records from capture DB, no duplicate with normalized May-Aug
for row_number,r in enumerate(orig_cap,2):
 ds=str(r.get('日付') or '')
 if ds>='2026-05-01':continue
 time=r.get('時刻') or ''
 try:dt=datetime.datetime.strptime(ds+' '+str(time), '%Y-%m-%d %H:%M')
 except ValueError:dt=None
 old=(r.get('イベント') or '').strip()
 # Critical: ambiguous capture/sighting is never upgraded to a confirmed owner capture
 etype={'capture':'HISTORICAL_REPORTED_CAPTURE','capture_or_sighting':'HISTORICAL_UNRESOLVED_CAPTURE_OR_SIGHTING','sighting':'SIGHTING_HABU','roadkill_sighting':'ROADKILL_HABU','no_capture':'HISTORICAL_NONCAPTURE_UNVERIFIED','轢死':'ROADKILL_HABU','捕獲':'HISTORICAL_REPORTED_CAPTURE','目撃':'SIGHTING_HABU'}.get(old,'HISTORICAL_OTHER')
 historical.append(dict(record_id='BASE_CAP_'+str(row_number-1),event_time_jst=dt.strftime('%Y-%m-%d %H:%M') if dt else ds+' '+str(time),exploration_night=opnight(dt) if dt else ds,event_class=etype,species_raw=r.get('種別') or '',species_normalized=r.get('種別') or '',count_raw=r.get('数') or '',count_min=r.get('数') or '',latitude=r.get('緯度') or '',longitude=r.get('経度') or '',surface_raw=r.get('天候') or '',surface_normalized='',size_raw=r.get('サイズ') or '',location_text=r.get('地域') or '',source_file='ハブDB_2025-2026_08-29完全統合版.xlsx',source_locator='捕獲DB row '+str(row_number),data_quality=r.get('確度') or 'BASE_LEGACY',review_reason='OLD_EVENT_TYPE_PRESERVED;OWNER_CAPTURE_NOT_REVALIDATED' if etype=='HISTORICAL_REPORTED_CAPTURE' else ('UNRESOLVED_CAPTURE_OR_SIGHTING' if etype=='HISTORICAL_UNRESOLVED_CAPTURE_OR_SIGHTING' else ''),original_sheet='捕獲DB',original_id=r.get('ID') or '',legacy_event_type=old,raw_event_excerpt=(r.get('メモ') or '')[:900]))

assert all(str(x['event_time_jst'])[:7] not in ('2026-09','2026-10') for x in historical)

# Combine historical and new fields without losing originals. Repeated past chat
# pastes are source views, not independent events; deduped new key is deterministic.
unified=[]
for row in historical:
 rec={key:'' for key in NEW_COLUMNS}
 rec.update({k:row.get(k,'') for k in NEW_COLUMNS})
 rec.update({'orig_sheet':row['original_sheet'],'orig_id':row['original_id']})
 rec['source_text']=row['raw_event_excerpt']
 rec['source_file']=row['source_file'];rec['source_locator']=row['source_locator']
 rec['provenance']='BASE_WORKBOOK_'+row['original_sheet']
 rec['dedup_status']='BASE_HISTORICAL_PRESERVED';unified.append(rec)
for row in new:
 rec=dict(row);rec['orig_sheet']='';rec['orig_id']=''
 unified.append(rec)
unified.sort(key=lambda x:(str(x['event_time_jst']),str(x['record_id'])))

# GPX matches: observe GPS near capture at event clock, within same operational night
# regardless of derived track filename; actual original files in /mnt/data.
gpx_files=sorted(ROOT.glob('*.gpx'))
canonical_track_files=[];seen_sha=set()
for f in gpx_files:
 digest=sha(f)
 if digest in seen_sha:continue
 seen_sha.add(digest);canonical_track_files.append((f,digest))

capture_new=[r for r in new if r['event_class']=='CAPTURE_HABU']
by_date=collections.defaultdict(list)
for r in capture_new:by_date[r['exploration_night']].append(r)
records_gpx=[]
try:
 from lxml import etree as ET
except ImportError:
 from xml.etree import ElementTree as ET
for f,sha256 in canonical_track_files:
 # Limit to Sept and October only.
 nm=re.search('2026-(0[89]|10)-(\d{2})',f.name)
 if not nm:continue
 name_night=f'2026-{nm.group(1)}-{nm.group(2)}'
 targets=by_date.get(name_night,[])
 if not targets:continue
 stats={r['record_id']:[float('inf'),None,0] for r in targets}
 ns='{http://www.topografix.com/GPX/1/1}'
 for _,elem in ET.iterparse(str(f),events=('end',)):
  if not str(elem.tag).endswith('trkpt'):
   continue
  try:
   lat=float(elem.attrib['lat']);lon=float(elem.attrib['lon'])
   el=elem.find(ns+'time');ts=el.text if el is not None else None
   if not ts:continue
   t=datetime.datetime.fromisoformat(ts.replace('Z','+00:00')).astimezone(datetime.timezone(datetime.timedelta(hours=9))).replace(tzinfo=None)
   for r in targets:
    delta=abs((t-datetime.datetime.strptime(r['event_time_jst'],'%Y-%m-%d %H:%M')).total_seconds())
    if delta>600:continue
    rlat=float(r['latitude']);rlon=float(r['longitude'])
    dlat=(lat-rlat)*111194.9;dlon=(lon-rlon)*111194.9*math.cos(math.radians(rlat))
    d=math.hypot(dlat,dlon)
    if d<stats[r['record_id']][0]:stats[r['record_id']]=[d,t.strftime('%Y-%m-%d %H:%M:%S'),delta]
  except (ValueError,KeyError):pass
  finally:elem.clear()
 for r in targets:
  d,t,td=stats[r['record_id']]
  records_gpx.append({'record_id':r['record_id'],'exploration_night':name_night,'capture_time_jst':r['event_time_jst'],'lat':r['latitude'],'lon':r['longitude'],'gpx_filename':f.name,'gpx_sha256':sha256,'nearest_distance_m':round(d,2) if math.isfinite(d) else '', 'nearest_point_time_jst':t or '', 'time_delta_seconds':td if math.isfinite(d) else '', 'gpx_match_status':'PASS_100M_10MIN' if d<=100 else 'FAIL_NO_NEAR_POINT'})
# File name in GPX 8/15 has an odd path but Sept 9/ no duplicate sha for same night
match_by_id={r['record_id']:r for r in records_gpx}
for r in capture_new:
 hit=match_by_id.get(r['record_id'])
 if not hit:
  records_gpx.append({'record_id':r['record_id'],'exploration_night':r['exploration_night'],'capture_time_jst':r['event_time_jst'],'lat':r['latitude'],'lon':r['longitude'],'gpx_filename':'','gpx_sha256':'','nearest_distance_m':'','nearest_point_time_jst':'','time_delta_seconds':'','gpx_match_status':'NOT_VERIFIED_GPX_MISSING'})

# View all base capture DB rows and the 67 Sept/October new verified capture events.
merged_capture_view=[]
for i,r in enumerate(orig_cap,2):
 old=r.get('イベント') or ''
 merged_capture_view.append({'source_record':'BASE_CAP_'+str(i-1),'date':r.get('日付') or '', 'time':r.get('時刻') or '', 'night':str(r.get('日付') or ''),'event_type_original':old,'classification':'LEGACY_UNRESOLVED' if old=='capture_or_sighting' else ('BASE_LABELED_CAPTURE_NEEDS_SOURCE_VALIDATION' if old in ('捕獲','capture') else 'NON_CAPTURE'), 'species':r.get('種別') or '', 'count':r.get('数') or '', 'size':r.get('サイズ') or '', 'area':r.get('地域') or '', 'lat':r.get('緯度') or '', 'lon':r.get('経度') or '', 'surface':'','source':'original workbook 捕獲DB', 'gpx_status':'NOT_REVALIDATED', 'note':r.get('メモ') or ''})
for r in sorted(capture_new,key=lambda x:x['event_time_jst']):
 hit=match_by_id.get(r['record_id'])
 merged_capture_view.append({'source_record':r['record_id'],'date':r['event_time_jst'][:10],'time':r['event_time_jst'][11:],'night':r['exploration_night'],'event_type_original':'捕獲','classification':'NEW_OWNER_CAPTURE_CONFIRMED_FROM_LOG','species':'ハブ','count':r['count_min'],'size':r['size_raw'],'area':r['location_text'],'lat':r['latitude'],'lon':r['longitude'],'surface':r['surface_raw'],'source':r['source_file'],'gpx_status':hit['gpx_match_status'] if hit else 'NOT_VERIFIED_GPX_MISSING','note':r['source_text']})

# Noncapture biological observations and reported Habu reactions from new evidence.
reaction_rows=[r for r in new if r['event_class'] in ('SIGHTING_OTHER','SIGHTING_HABU','ROADKILL_HABU','ROADKILL_OTHER','OTHER_PERSON_CAPTURE_HABU','OTHER_PERSON_CAPTURE_OTHER')]
by_night=collections.defaultdict(list)
for r in new:by_night[r['exploration_night']].append(r)
night_summary=[]
for night,g in sorted(by_night.items()):
 stats=collections.Counter(x['event_class'] for x in g)
 night_summary.append({'night':night,'events':len(g),'owner_captures':sum(int(x['count_min']) for x in g if x['event_class']=='CAPTURE_HABU'),'habu_sightings':stats['SIGHTING_HABU'],'habu_roadkills':stats['ROADKILL_HABU'],'others_capture_habu':stats['OTHER_PERSON_CAPTURE_HABU'],'other_animals':stats['SIGHTING_OTHER']+stats['ROADKILL_OTHER'],'weather_notes':stats['WEATHER_OR_MEMO'],'starts':stats['SESSION_START'],'ends':stats['SESSION_END'],'capture_gpx_pass':sum(x['gpx_match_status']=='PASS_100M_10MIN' for x in records_gpx if x['exploration_night']==night),'capture_gpx_not_verified':sum(x['gpx_match_status']=='NOT_VERIFIED_GPX_MISSING' for x in records_gpx if x['exploration_night']==night)})

exceptions=[{'source':'SEPT','event_id':x['event_id'],'timestamp':x['event_time'],'issue':x['issue'],'action':'PRESERVE_UNALTERED'} for x in sep_errors]
exceptions.extend([{'source':'OCT_USER_CHAT','event_id':'','timestamp':'2026-10-18 18:48','issue':'SESSION_END_AND_START_SAME_MINUTE','action':'EXCLUDE_UNPAIRED_END_FROM_CANONICAL;PRESERVE_NOTE'}])
exceptions.extend([{'source':'DEDUP_NEARBY','event_id':x['event_a'],'timestamp':x['time'],'issue':x['reason'],'action':'RETAIN_BOTH;REVIEW'} for x in collisions])
exceptions.extend([{'source':'OCT_USER_CHAT','event_id':r['record_id'],'timestamp':r['event_time_jst'],'issue':r['review_reason'],'action':'PRESERVE_COMBINED_SPECIES_COUNT'} for r in octs if r['review_reason']])

individuals=[]
for event in sorted(capture_new,key=lambda x:(x['event_time_jst'],x['record_id'])):
 for index in range(1,int(event['count_min'])+1):
  individuals.append({'individual_id':event['record_id']+f'-{index:02d}','event_id':event['record_id'],
    'individual_index':index,'event_time_jst':event['event_time_jst'],
    'exploration_night':event['exploration_night'],'species':'ハブ',
    'latitude':event['latitude'],'longitude':event['longitude'],'size_raw':event['size_raw'],
    'sex':event['sex'],'source_file':event['source_file'],'source_locator':event['source_locator'],
    'event_count':int(event['count_min']),'count_provenance':event['source_text'] if int(event['count_min'])>1 else ''})
assert len(individuals)==68
assert len({r['individual_id'] for r in individuals})==68
write_csv(OUT/'新規ハブ捕獲個体_2026-09_10.csv',individuals,list(individuals[0]))
write_csv(OUT/'新規イベント_2026-09_10.csv',new,NEW_COLUMNS)
write_csv(OUT/'全期間イベント統合_2025-2026.csv',unified,NEW_COLUMNS+['orig_sheet','orig_id'])
write_csv(OUT/'本人捕獲_全期間原DB+追加.csv',merged_capture_view,list(merged_capture_view[0]))
write_csv(OUT/'新規ハブ捕獲_2026-09_10.csv',capture_new,NEW_COLUMNS)
write_csv(OUT/'新規生物反応_2026-09_10.csv',reaction_rows,NEW_COLUMNS)
write_csv(OUT/'探索夜別_2026-09_10.csv',night_summary,list(night_summary[0]))
write_csv(OUT/'GPS照合_新規本人捕獲.csv',sorted(records_gpx,key=lambda r:r['capture_time_jst']),list(records_gpx[0]))
write_csv(OUT/'要確認_例外候補.csv',exceptions,['source','event_id','timestamp','issue','action'])
write_csv(OUT/'重複監査_同一イベント.csv',dups,['removed_record_id','retained_record_id','timestamp','reason','duplicate_sha','source'])

manifest={
 'project':'ハブAI','schema':'habu-data-integration-2026-10-21-v1','creation_date':'2026-10-21',
 'base_workbook':'ハブDB_2025-2026_08-29完全統合版.xlsx','base_sha256':sha(ROOT/'ハブDB_2025-2026_08-29完全統合版.xlsx'),
 'base_original_sheets':['README','ダッシュボード','捕獲DB','生物反応DB','正規化イベントDB','要確認一覧','新規ハブ監査_8月','取込サマリー_8月','月別自動集計','日別自動集計'],
 'base_normalized_rows':len(orig_norm),'base_legacy_rows_before_may_2026':len(historical)-len(orig_norm),'base_capture_view_rows':len(orig_cap),
 'september_original':'ハブログ9月.txt','september_sha256':sha(ROOT/'ハブログ9月.txt'),'september_blocks':len(seps),'september_capture_events':50,'september_captured_individuals':51,
 'october_source':'habu_october_compact_source_20261021.txt','october_note':'2026-10-06/08/14/15/16/18/20 user-chat transcription; NOT byte-identical raw export; Oct06-15 referenced against GitHub PR#39', 'october_sha256':sha(ROOT/'habu_october_compact_source_20261021.txt'),'october_records':len(octs),'october_capture_events':17,'october_captured_individuals':17,
 'new_events_unique':len(new),'special_case_2026_09_29_0000':{'operational_night':'2026-09-28','capture_events':1,'individuals':2,'source_literal':'畑 枯れ木 2匹','existing_github_main_individuals':2},'removed_true_duplicates_in_distinct_selected_sources':len(dups),'repeated_chat_posts':'same 2026 October log was pasted repeatedly; only one normalized pass selected, not counted as additional nights',
 'historic_events_merged_in_master':len(historical),'total_unified_events':len(unified),
 'new_habu_capture_events':len(capture_new),'new_habu_captured_individuals':sum(int(r['count_min']) for r in capture_new),'new_reaction_records':len(reaction_rows),
 'new_gpx_pass_count':sum(r['gpx_match_status']=='PASS_100M_10MIN' for r in records_gpx),'gpx_event_count_not_individual_count':True,
 'new_gpx_missing_count':sum(r['gpx_match_status']=='NOT_VERIFIED_GPX_MISSING' for r in records_gpx),
 'uncertainty_notes':['Existing 2025 capture_or_sighting rows remain ambiguous','Oct18 18:48 conflicting SESSION_END ignored as anomaly, START retained','Mixed species with single count are not expanded per species','GPS noncapture never becomes ecological true Negative','2026 May-Aug baseline normalization kept in original order; duplicate baseline CaptureDB entries not double-imported into merged event table','Only September and October event counts newly additive; historical base capture count is not recertified'],
 'replay_and_original_policy':'Do not alter any immutable prediction ORIGINAL/P0 and do not claim official PDCA evaluation.',
 'source_digests':{'base_xlsx':sha(ROOT/'ハブDB_2025-2026_08-29完全統合版.xlsx'),'september_txt':sha(ROOT/'ハブログ9月.txt'),'october_transcribed_txt':sha(ROOT/'habu_october_compact_source_20261021.txt')}
}
(OUT/'取込マニフェスト.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'監査説明.md').write_text(f'''# ハブAI 2025〜2026年10月20日 統合監査\n\n- 元DBは一切変更しない。コピーする際も既存10シートは元の意味のまま保持。\n- 2026年9月の原本ログ: **{len(seps)}件**（本人捕獲50イベント、**51個体**）。\n- 2026年10月6・8・14・15・16・18・20日のユーザー記録: **{len(octs)}件**（本人捕獲17イベント、17個体）。\n- 追加合計: **{len(new)}件、本人捕獲67イベント、**68個体****。同一イベントは決定的キーで1回だけ登録。\n- 2025〜2026年8月の既存正規化イベント{len(orig_norm)}件＋同年5月以前の旧捕獲DBから{len(historical)-len(orig_norm)}件＋新規{len(new)}件＝**{len(unified)}件**。\n- 『2025年捕獲または目撃』等の曖昧行は確定捕獲へ改変しない。\n- 同じ日時でも異なる緯度経度、異種、別捕獲は保持する。月跨ぎは07:00区切り。\n- 複数生物名＋1匹は種ごとの匹数とみなさない。\n- 10月18日18:48には『探索終了』と『探索開始』が同時記載。終了は不整合候補として隔離し、開始を保持。\n- 9月原本は文字列として保持。10月は会話を手動転記した構造化原簿で、原文のバイト単位の保全とは区別する。\n- 同内容の過去ログが複数回チャットに貼られても、登録イベントを増やさない。\n- GPXとの照合は日時±10分かつ距離100m以内。未存在・未一致は別状態とする。\n- 原因分析・事後再予測と正式P0は区別。\n- 既存ブックの『捕獲DB』やダッシュボードは2026年8月時点のスナップショットであり、9・10月の値へ自動拡張しない。新規の統合シート・集計を正本候補として利用。\n\n**原本**: 2025年からの統合版 / 2026年9月ログ / 2026年10月チャット記録 / GPS。\n''',encoding='utf-8')
print(json.dumps({'new_events':len(new),'sept':len(seps),'oct':len(octs),'captures':len(capture_new),'historical':len(historical),'merged':len(unified),'gpX_counts':collections.Counter(r['gpx_match_status'] for r in records_gpx),'nights':len(night_summary),'exceptions':len(exceptions),'summary':night_summary},ensure_ascii=False,indent=2))
